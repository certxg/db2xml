This directory contains samples and test data.
A copy of it can be found at 

http://test.xmlsh.org
