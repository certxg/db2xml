# Requires xmlsh in your path
clear
xmlsh demo.xsh
