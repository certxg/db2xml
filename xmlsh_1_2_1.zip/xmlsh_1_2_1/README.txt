Installation and getting started instructions are available at 

http://www.xmlsh.org

The "Quick Start" has directions on how to get up and running

http://www.xmlsh.org/QuickStart

